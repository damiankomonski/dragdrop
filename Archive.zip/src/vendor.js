import 'angular';
import 'angular-ui-router';
import 'angular-hammer';
